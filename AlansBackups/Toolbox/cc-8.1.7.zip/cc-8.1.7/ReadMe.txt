CC for Windows Version 8.1.7      November 2006 

The Consistent Changes (CC) program is useful for finding all 
occurrences of specified characters, words, or phrases in a 
text file or series of text files, and making some type of 
change to this data in a consistent way. The change can be 
done in every occurrence found or only when certain 
conditions are met. 

The files in this package include:
	CC for Windows (CCW.exe, CCW32.exe)
	the CC Dynamic Link Libraries (DLLs)
	CC Debugger for Win95 and later (CCDbg32.exe)
	CC for DOS
	CC User Documentation
	CC Libraries, for programmers

See CCWin\Doc\CCFiles.doc for details on these files.
Users new to CC can see CCWin\Doc\CC.doc, a User Guide to 
writing "CC tables" for using CC.

This version has Unicode Support. See The File "Teaching an Old Dog New Tricks.doc"
in the Doc directory for more details.

------------ 
Installation
------------ 
Manual installation is straightforward:

Copy the .exe files from the CCWin folder to an appropriate
location on your hard disk, such as C:\Program Files\CCWin .
Users with Windows 95 or later can use CCW32.exe rather than
CCW.exe. Win 3.1 users must use CCW.exe.

Win9x/ME:
Copy both CC.dll and CC32.dll from the CCWin\DLL folder into 
the C:\Windows\System folder. 

Win2K/XP
Copy both CC.dll and CC32.dll from the CCWin\DLL folder into 
the C:\Windows\System32 folder or C:\Winnt\System32 folder. 

------------------
New Features 8.1.7
------------------
1. Increase the maximum path length to 860 characters
2. Drop 16 bit support

------------------
New Features 8.1.6
------------------
1. Handle CC tables with Unicode BOM.

------------------
New Features 8.1.5
------------------
1. Unicode Support. See The File "Teaching an Old Dog New Tricks.doc"
in the Doc directory for more details.

2. The maximum number of groups and stores has been increased from 127 to 1000.

-------------------
New Features 8.0.16
-------------------
CCW and CCW32 have the following new features:
  
1) Ganged CC tables. Multiple CC tables can now be specified. The input is run 
through the first CC table, the output of that process is run through the second
CC table and so on until the last CC table. The result of running the data 
through the last CC table is then output to the output file. Multiple CC tables 
must be separated by commas in the the CC specification in the main dialog box, 
or after the -t option on the command line. Example:
  
ccw32 -t 1.cc, 2.cc -o test.out test.in
  
This command will feed test.in through 1.cc, the results of which will be fed 
through 2.cc, and then output to test.out.
  
2) An list of output files can now be specified similar to how a list of input files 
are specified. The number of output files must match the number of input files. 
If the list of output files is specified on the command line or in the main 
dialog box, then the files must be separated by a comma. If the list of output 
files is specified in a file, then each file name must occur on a line by 
itself. A new command line option, -ol indicates that the output file is 
actually a file containing a list of output files.
Examples:
  
ccw32 -t test.cc -o first.out, second.out, 3.out 1.in 2.in 3.in
  
This command will process 1.in through test.cc, producing first.out, 2.in through 
test.cc, producing second.out, and 3.in through test.cc producing 3.out. It may at 
first glance appear that there is an ambiguity in what the input and output 
files are, but the commas in the output file specification resolve this 
ambiguity.
  
Example:
  
ccw32 -t test.cc -ol output.lst -i input.lst
  
output.lst contains:
  
first.out
second.out
3.out
  
input.lst contains
  
1.in
2.in
3.in
  
The above produces the same results as the first command.
  
3) Command history is available in the main dialog box. This will keep track 
of previous runs, and fill in the dialog box when a previous run is selected.
  
Note that in spite of the above additional features, the standard cc command 
line syntax will still work with CCW. However, the new features are not 
available in the DOS version.

--------
Feedback
-------- 
Please email your feedback on this software to Doug Rintoul, with a 
copy to Team Shoebox (doug_rintoul@sil.org, team_shoebox@sil.org). 
