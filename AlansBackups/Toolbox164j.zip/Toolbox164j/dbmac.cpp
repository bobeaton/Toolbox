// dbmac.cpp Database, record, and field Alan Buseman 21 Oct 06

#include "generic.h"
#include "dbmac.h"

#ifdef AFX_DATA
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif // AFX_DATA

