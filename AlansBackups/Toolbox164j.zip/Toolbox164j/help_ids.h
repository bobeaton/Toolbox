// help_ids.h - User-defined Help IDs
// Valid user-defined help IDs must be in the range 0x00000000 - 0x0000FFFF

#define HT_CONVERT_CHAR_RANGE_SET   0000
#define HT_VERSION_INFORMATION      0001
#define HT_WORD_FORMULAS_RECURSION  0002
