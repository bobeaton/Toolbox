// ddx.h  Shoebox custom dialog data exchange

BOOL Shw_bNeedsToBeTrimmed(const char* pszText, int *plenPrecedingWS, int* plenFollowingWS);
