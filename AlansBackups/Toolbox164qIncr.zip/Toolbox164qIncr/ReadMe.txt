Toolbox test version 1.6.4q Nov 2021

New features since release 1.6.4

Make Leipzig Glossing Rules setup work well.
Make large corpus approach with WordParse.txt work well.
Fix bug of false forced gloss not found message on lookup with spaces.
Fix bug of messed up cursor on delete back into interlinear.

To install a test version, put the Toolbox.exe test version file in place 
of Toolbox.exe in Program Files. It is best to rename the one you 
replace to something like Toolbox163.exe so you can go back to 
it if you have problems with the test version.

