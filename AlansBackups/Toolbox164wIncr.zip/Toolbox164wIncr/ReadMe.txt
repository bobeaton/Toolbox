Toolbox test version 1.6.4w Jan 2021

New features since release 1.6.4

Make large corpus approach with WordParse.txt work well.
Fix bug of not aligning in lookup from WordParse.
Make return from jump work from WordParse after return from dictionary.
Fix bug of fail to interlinearize if at end of empty field.
Jump insert into dictionary from WordParse interlinearize without asking.
Jump insert into WordParse file from text interlinearize without asking.
Fix bug of incorrect alignment on WordParse lookup.
Fix bug of false forced gloss not found message on lookup with spaces.
Fix bug of messed up cursor on delete back into interlinear.
Show lexicon highlighting for AGNT databases.


