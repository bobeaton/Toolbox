Toolbox test version 1.6.4n Aug 2020

New features since release 1.6.4

Fix bug of messed up cursor on delete back into interlinear.
Fix bug of false forced gloss not found message on lookup with spaces.
Show lexicon highlighting for AGNT databases.


